#pragma once
#include <json/json.h>
#include <string>

class LightingSceneDefinition;
Json::Value describeDesktopLighting(const LightingSceneDefinition&, const Json::Value& switches);
Json::Value describeDesktopMaterial(const std::string& name);
