"""Bundle the pinned upstream parser, expansion engine and headless scene generator."""
from catalog_chunks import split_catalog
import argparse
import concurrent.futures
import os
from pathlib import Path
import re
import shutil
import hashlib
import zipfile
import subprocess

here = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--objects-only', action='store_true')
parser.add_argument('--host', action='store_true')
options = parser.parse_args()
external = os.environ.get('PROGEN3D_CHECKOUT')
glm = Path(os.environ['GLM_INCLUDE']).resolve()
compiler = 'g++' if options.host else (os.environ.get('EMXX') or str(Path(os.environ['EMSDK']).resolve()/'upstream/emscripten/em++'))
build = Path(os.environ.get('GRAMMAR_BUILD_DIR',str(here/('build-host' if options.host else 'build-wasm')))).resolve()
build.mkdir(parents=True, exist_ok=True)
def run(args): subprocess.run(args, check=True)
if external:
    repo = Path(external).resolve()
    commit = subprocess.check_output(['git','-C',repo,'rev-parse','HEAD'],text=True).strip()
    if commit != (here/'desktop-commit.txt').read_text().strip(): raise SystemExit('Unexpected revision '+commit)
else:
    repo = build/'pinned'
    archive = here/'upstream-snapshot.zip'
    if hashlib.sha256(archive.read_bytes()).hexdigest() != (here/'snapshot.sha256').read_text().strip():
        raise SystemExit('Invalid source snapshot.')
    if not (repo/'.snapshot').exists() or (repo/'.snapshot').read_text() != (here/'snapshot.sha256').read_text():
        with zipfile.ZipFile(archive) as source_zip: source_zip.extractall(repo)
        (repo/'.snapshot').write_text((here/'snapshot.sha256').read_text())
overlay = build/'mobile-overlay'
patches = [here/'service-interface.patch', here/'higher-dimensional.patch']
if overlay.exists():
    shutil.rmtree(overlay)
overlay.mkdir()
for patch in patches:
    for name in re.findall(r'^\+\+\+ b/(.+)$', patch.read_text(), re.MULTILINE):
        target = overlay/name
        if not target.exists():
            target.parent.mkdir(exist_ok=True,parents=True)
            if (repo/name).is_file(): shutil.copyfile(repo/name,target)
    run(['patch','--batch','--quiet','-p1','-d',overlay,'-i',patch])
# Each patch revision has its own objects, including unchanged translation
# units that depend on patched headers.
revision = hashlib.sha256((here/'snapshot.sha256').read_bytes() + b''.join(patch.read_bytes() for patch in patches)).hexdigest()
object_directory = build / ('objects-' + revision[:16])
object_directory.mkdir(exist_ok=True)
jsonsrc = here.parent/'upstream_port/veg'
sources = [repo/s for s in (here/'sources.txt').read_text().splitlines() if s]
sources += [jsonsrc/'src/json_value.cpp',jsonsrc/'src/json_writer.cpp',jsonsrc/'src/json_reader.cpp']
# Use the desktop preview's exact cube vertex data and coordinate convention.
desktop = (repo/'src/imgui_render.cpp').read_text()
vertices = re.search(r'const GLfloat kVertexData\[\] = \{.*?\};',desktop,re.S)[0]
cube = re.search(r'std::array<GLfloat, 36 \* 8> build_base_vertex_data\(\)\s*\{.*?\n\}',desktop,re.S)[0]
cube_file = build/'native_cube.cpp'
cube_file.write_text('#include <array>\nusing GLfloat=float;\n'+vertices+'\n'+cube+'\n')
sources += [cube_file]
if not options.objects_only: sources += [here/'mobile_scene.cpp', here/'mobile_mesh_catalog.cpp', here/'mobile_desktop_scene.cpp']
def compile_one(source):
    name = str(source.relative_to(repo)) if source.is_relative_to(repo) else source.name
    obj=object_directory/(name.replace('/','_')+'.o')
    generated_catalog = source.name == 'SmallModernBuildingKnowledgeCatalog.cpp'
    if generated_catalog and not options.host:
        chunked = build/'mobile_catalog_chunks.cpp'
        content = split_catalog(source.read_text())
        if not chunked.is_file() or chunked.read_text() != content:
            chunked.write_text(content)
        source = chunked
        obj = object_directory/'mobile_catalog_chunks.o'
    if source.is_relative_to(repo):
        patched_source = overlay/source.relative_to(repo)
        if patched_source.is_file():
            source = patched_source
    dependencies = [source]
    if source.name == 'mobile_desktop_scene.cpp':
        dependencies.extend([here/'desktop_material.inc', here/'mobile_desktop_scene.h'])
    if source.name == 'mobile_scene.cpp':
        dependencies.append(here/'mobile_desktop_scene.h')
    if not obj.exists() or any(obj.stat().st_mtime < dep.stat().st_mtime for dep in dependencies):
        # The generated catalogue is a megabyte of constant constructors. Optimising
        # that translation unit spends minutes inlining table initialisation.
        optimization = '-O0' if generated_catalog else '-O1'
        run(['g++' if options.host else compiler,'-std=c++17',optimization,'-fexceptions','-ffunction-sections','-fdata-sections',
             '-DNDEBUG','-DJSON_USE_EXCEPTION=1','-w','-I'+str(overlay/'include'),'-I'+str(repo/'include'),'-I'+str(repo),
             '-I'+str(repo/'third_party/vendor/glad/include'),'-I'+str(glm),
             '-I'+str(jsonsrc/'include'),'-c',source,'-o',obj])
    return obj
with concurrent.futures.ThreadPoolExecutor(int(os.environ.get('GRAMMAR_JOBS','6'))) as pool:
    objects=list(pool.map(compile_one,sources))
if not options.objects_only:
    if options.host:
        run(['g++','-Wl,--gc-sections',*objects,'-o',build/'native-scene'])
        raise SystemExit(0)
    dest=here.parent/'app/assets/modules/native-engine.js'
    run([compiler,'--no-entry','-O1','-fexceptions','-sMODULARIZE=1','-sEXPORT_NAME=createProgenNative',
         '-sENVIRONMENT=worker,node','-sALLOW_MEMORY_GROWTH=1','-sMAXIMUM_MEMORY=536870912','-sSTACK_SIZE=3145728',
         '-sDISABLE_EXCEPTION_CATCHING=0','-sFILESYSTEM=1','-sEXPORTED_RUNTIME_METHODS=UTF8ToString,FS',
         '-sEXPORTED_FUNCTIONS=_scene_compile,_scene_compile_options,_scene_vertices,_malloc,_free',*objects,'-o',dest])
