// Adapter between the offline mobile workbench and ProGen3D's native scene model.
#include "mobile_desktop_scene.h"
#include "grammar.h"
#include <sstream>
#include "GrammarRuntime.h"
#include "Context.h"
#include "lighting/model/LightingSceneDefinition.h"
#include "vehicle/model/VehicleJointGraph.h"
#include "spatial/model/SpatialBuildingModel.h"
#include <json/json.h>
#include <algorithm>
#include <array>
#include <cmath>
#include <fstream>
#include <iostream>
#include <map>
#include <random>
#include <stdexcept>
#include <string>
#include <vector>

std::mt19937_64 grammar_rng, effects_rng;
std::array<GLfloat, 36 * 8> build_base_vertex_data();

void registerPackagedVehicleMeshes();

namespace {
std::vector<float> vertices;
std::vector<std::string> executionErrors;
std::string resultText;

Json::Value vectorValue(const glm::vec3& point) {
    Json::Value result(Json::arrayValue);
    for (int i=0; i<3; ++i) result.append(point[i]);
    return result;
}
Json::Value span(int line, int column, int lastLine, int lastColumn) {
    Json::Value result(Json::arrayValue);
    for (int value : {line,column,lastLine,lastColumn}) result.append(value);
    return result;
}
void diagnostic(Json::Value& result,const std::string& message,Json::Value where=Json::nullValue) {
    Json::Value issue; issue["message"]=message; issue["span"]=std::move(where);
    if(result["issues"].size()<32) result["issues"].append(std::move(issue));
}
Json::Value compile(const std::string& input, unsigned seed, double time, const Json::Value& options) {
    Json::Value result;
    result["ok"]=false; result["issues"]=Json::arrayValue; result["parts"]=Json::arrayValue;
    if (input.size()>2097152 || input.empty()) {diagnostic(result,"Expected 1 to 2,097,152 bytes of grammar.");return result;}
    registerPackagedVehicleMeshes();
    GrammarDocument grammar;
    if (!setGrammarEvaluationTime(&grammar,time)) { diagnostic(result,"Time must be finite and representable.");return result;}
    grammar_rng.seed(seed); effects_rng.seed(seed);
    setGrammarEvaluationDiagnosticsQuiet(&grammar,true);
    grammar.loadFromSourceText(input,"mobile-editor");
    if (grammar.error_details.empty()) {
        std::size_t count = 0;
        for (const auto* token : grammar.tokens_new) if(token && token->token_name=="I") ++count;
        if(count>5000 || grammar.tokens_new.size()>80000){
            diagnostic(result,"Mobile preview supports 5,000 instances and 80,000 expanded actions.");return result;
        }
        grammar.addContext(); grammar.context->genPrimitives(); grammar.generateGeometry();
    }
    for (const auto& issue : grammar.error_details)
        diagnostic(result,issue.message,span(issue.line,issue.start_column,issue.line,issue.end_column));
    for (const auto& message : executionErrors) diagnostic(result,message);
    if (!result["issues"].empty() || !grammar.context) return result;

    auto& scene=*grammar.context;
    const bool airflow=std::any_of(scene.primitive_instances.begin(),scene.primitive_instances.end(),
        [](const auto& part){return bool(part.airflow);});
    const bool explicitReplay = options["physicsTime"].isNumeric();
    if (explicitReplay || (airflow && !grammarUsesTime(&grammar))) {
        const double replay = explicitReplay ? options["physicsTime"].asDouble() : time;
        if (!std::isfinite(replay) || replay<0 || replay>60) {diagnostic(result,"Physics replay supports 0 to 60 seconds.");return result;}
        constexpr int hz=120;
        const auto ticks=static_cast<unsigned>(replay*hz);
        const bool dynamic=std::any_of(scene.primitive_instances.begin(),scene.primitive_instances.end(),
            [](const auto& part){return !part.immovable;});
        if (dynamic) {
            const double count = scene.primitive_instances.size();
            if ((ticks+1)*count>500000 || (ticks && ticks*count*count>50000000)) {
                diagnostic(result,"Physics replay exceeds the mobile instance-step budget. Reduce time or scene size.");return result;
            }
            for(unsigned i=0;i<ticks;++i) scene.stepSimulation(1.f/hz);
            const float remainder=static_cast<float>(replay-ticks/double(hz));
            if(remainder>1e-8f) scene.stepSimulation(remainder);
        } else scene.time=static_cast<float>(replay);
        result["physicsTime"] = replay;
    }
    result["airflow"]=airflow;
    result["lighting"] = describeDesktopLighting(scene.lightingSceneDefinition(), options["switches"]);
    result["materials"] = Json::objectValue;
    result["spatialObjects"] = Json::objectValue;
    result["rules"]=unsigned(grammar.rule_list.size()); result["usesTime"]=grammarUsesTime(&grammar) || airflow;
    result["gravity"]=vectorValue(scene.getGravity());
    result["lights"]=unsigned(scene.lightingSceneDefinition().lights().size());
    result["joints"]=unsigned(scene.vehicleJointGraph().joints().size());
    result["serviceConnections"]=0; result["objects"]=0; result["interfaces"]=0; result["connections"]=0; result["constraints"]=0;
    std::map<size_t,std::string> owners;
    if (const auto& model=scene.spatialBuildingModel()) {
        result["objects"]=unsigned(model->objects().size());
        result["connections"]=unsigned(model->connectionGraph().connections().size());
        result["constraints"]=unsigned(model->constraintGraph().constraints().size());
        unsigned interfaces=0;
        unsigned serviceCount=0;
        for(const auto& object:model->objects().objects()){
            const auto& identity = object.identity();
            auto& row = result["spatialObjects"][identity.objectId().value()];
            row["name"] = identity.objectName();
            row["class"] = identity.objectClass().value();
            row["taxonomy"] = Json::arrayValue;
            row["interfaces"] = Json::arrayValue;
            for (const auto& segment : identity.taxonomyPath().segments()) row["taxonomy"].append(segment);
            for (const auto& port : object.interfaces()) row["interfaces"].append(port.interfaceId().value());
            interfaces+=object.interfaces().size();
            for(const auto& iface:object.interfaces()) if(iface.type()==SpatialInterfaceType::ServiceConnection) ++serviceCount;
        }
        result["serviceConnections"]=serviceCount;
        result["interfaces"]=interfaces;
        for(const auto& binding:model->geometryBindings()) owners[binding.primitiveInstanceIndex()]=binding.objectId().value();
    }
    size_t drawVertices=0;
    for(const auto& part:scene.primitive_instances){
        if(part.removed || !part.resolved_geometry) continue;
        const auto& mesh=*part.resolved_geometry;
        if(mesh.hasTriangleMesh()) drawVertices+=mesh.triangleVertexCount();
        else if(mesh.usesCubeVertexTemplate()) drawVertices+=36u;
        if(drawVertices>600000u*3u) {
            diagnostic(result,"Scene exceeds the mobile limit of 600,000 triangles. Reduce detail or repetitions to preview it.");return result;
        }
    }
    vertices.reserve(drawVertices*8);
    const auto cube=build_base_vertex_data();
    for(size_t i=0;i<scene.primitive_instances.size();++i) {
        const auto& part=scene.primitive_instances[i];
        if(part.removed) continue;
        const size_t start=vertices.size();
        scene.buildInstanceBuffer(part,cube.data(),&vertices);
        if(vertices.size()>8u*3u*600000u) {
            diagnostic(result,"Mobile preview exceeded 600,000 triangles.");return result;
        }
        Json::Value item;
        if (!result["materials"].isMember(part.material_name)) {
            result["materials"][part.material_name] = describeDesktopMaterial(part.material_name);
        }
        item["position"] = vectorValue(part.position);
        item["sleeping"] = part.sleeping;
        item["type"]=part.type; item["material"]=part.material_name;
        item["alpha"]=part.alpha; item["mass"]=part.mass; item["fixed"]=part.immovable;
        if (part.airflow) {
            const auto air=scene.inspectAirflow(part);
            auto& loads=item["airflow"];
            loads["force"]=vectorValue(air.force);loads["moment"]=vectorValue(air.moment);
            loads["thrust"]=air.thrust;loads["shaftPower"]=air.shaftPower;loads["shaftTorque"]=air.shaftTorque;
            loads["withinRange"]=air.withinRange;
            if(!part.airflow->ductStations.empty()){
                const auto point=part.airflow->ductOperatingPoint();loads["uniqueFlow"]=point.unique();
                if(point.unique()) {loads["flow"]=point.flow;loads["pressure"]=point.pressure;}
            }
        }
        item["velocity"]=vectorValue(part.velocity); item["angularVelocity"]=vectorValue(part.rotational_velocity);
        item["span"]=span(part.source_start_line,part.source_start_column,part.source_end_line,part.source_end_column);
        item["first"]=unsigned(start/8); item["count"]=unsigned((vertices.size()-start)/8);
        item["object"]=owners.count(i)?owners.at(i):std::string();
        result["parts"].append(std::move(item));
    }
    if(!std::all_of(vertices.begin(),vertices.end(),[](float v){return std::isfinite(v);})) {
        diagnostic(result,"Generated coordinates contain a non-finite value.");return result;
    }
    result["floats"]=unsigned(vertices.size());result["ok"]=true;
    return result;
}
}
void errorout(std::string message) {
    if(executionErrors.size()<32 && !message.empty() &&
       std::find(executionErrors.begin(),executionErrors.end(),message)==executionErrors.end())
        executionErrors.push_back(std::move(message));
}
void debugout(const std::string&) {}
extern "C" const char* scene_compile_options(const char* data, size_t size, unsigned seed, double time, const char* settings) {
    vertices.clear(); executionErrors.clear();Json::Value result;
    try {
        Json::Value options(Json::objectValue);
        if (settings && *settings) {
            std::istringstream stream(settings);
            stream >> options;
            if (!options.isObject()) throw std::invalid_argument("Invalid preview options.");
        }
        result=compile(std::string(data,size),seed,time,options);
    }
    catch(const std::bad_alloc&) {result["ok"]=false;diagnostic(result,"Native preview could not allocate enough memory. Reduce detail or repetitions and build again.");}
    catch(const std::exception& error) {result["ok"]=false;diagnostic(result,error.what());}
    catch(...) {result["ok"]=false;diagnostic(result,"The native engine stopped during generation.");}
    if(!result["ok"].asBool()) {vertices.clear();result.removeMember("parts");}
    Json::StreamWriterBuilder writer;writer["indentation"]="";
    resultText=Json::writeString(writer,result);
    return resultText.c_str();
}
extern "C" const char* scene_compile(const char* data, size_t size, unsigned seed, double time) {
    return scene_compile_options(data, size, seed, time, nullptr);
}
extern "C" const float* scene_vertices() {return vertices.data();}
#ifndef __EMSCRIPTEN__
int main(int argc,char** argv) {
    if(argc!=5 && argc!=6)return 2;
    std::ifstream in(argv[1],std::ios::binary);
    if(!in)return 1;
    const std::string input{std::istreambuf_iterator<char>(in),{}};
    std::cout<<scene_compile_options(input.data(),input.size(),std::stoul(argv[2]),std::stod(argv[3]),argc==6?argv[5]:nullptr)<<"\n";
    std::ofstream out(argv[4],std::ios::binary);
    out.write(reinterpret_cast<const char*>(vertices.data()),vertices.size()*sizeof(float));
}
#endif
