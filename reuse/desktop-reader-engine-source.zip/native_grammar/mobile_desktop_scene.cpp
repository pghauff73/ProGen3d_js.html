#include "mobile_desktop_scene.h"
#include "lighting/model/LightingSceneDefinition.h"
#include "lighting/service/GpuLightRecordFactory.h"
#include "electrical/service/ElectricalControlValidationService.h"
#include "electrical/service/LightingStateEvaluator.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <sstream>
#include <iomanip>
#include <string_view>

namespace {
#include "desktop_material.inc"

Json::Value channels(glm::vec4 value) {
    Json::Value result(Json::arrayValue);
    for (int i = 0; i < 4; ++i) result.append(value[i]);
    return result;
}
template<class Id> Json::Value identifiers(const std::vector<Id>& ids) {
    Json::Value result(Json::arrayValue);
    for (const auto& id : ids) result.append(id.value());
    return result;
}
}

Json::Value describeDesktopMaterial(const std::string& name) {
    const auto material = parse_material_name(name);
    Json::Value result;
    result["family"] = material.family;
    result["description"] = material.description;
    result["opacity"] = material.opacity;
    result["smoothness"] = material.smoothness;
    result["reflectance"] = material.reflectance;
    result["emission"] = material.emission_strength;
    result["transmission"] = material.transmission;
    result["ior"] = material.index_of_refraction;
    for (const auto& color : material.palette) {
        Json::Value rgb(Json::arrayValue);
        for (float channel : {color.r, color.g, color.b}) rgb.append(channel);
        result["palette"].append(rgb);
    }
    return result;
}

Json::Value describeDesktopLighting(const LightingSceneDefinition& definition, const Json::Value& overrides) {
    auto graph = definition.electricalControlGraph();
    Json::Value result;
    for (const char* field : {"switches", "circuits", "lights", "diagnostics"})
        result[field] = Json::arrayValue;
    result["fixtures"] = static_cast<unsigned>(graph.fixtures().size());
    for (auto& control : graph.switches()) {
        const auto& id = control.id().value();
        const auto& change = overrides[id];
        if (change.isObject()) {
            if (change["on"].isBool()) control.state().on = change["on"].asBool();
            if (change["dimmer"].isNumeric()) control.state().dimmer = std::clamp(change["dimmer"].asFloat(), 0.f, 1.f);
        }
        Json::Value row;
        row["id"] = id;
        row["name"] = control.name();
        row["on"] = control.state().on;
        row["dimmer"] = control.state().dimmer;
        row["variable"] = control.type() == SwitchType::Dimmer || control.type() == SwitchType::Smart ||
                          control.type() == SwitchType::SceneController;
        row["mount"] = control.mountObjectId();
        row["height"] = control.mountHeight();
        result["switches"].append(row);
    }
    for (const auto& circuit : graph.circuits()) {
        Json::Value row;
        row["id"] = circuit.id().value();
        row["fixtures"] = identifiers(circuit.fixtureIds());
        row["controls"] = identifiers(circuit.controlIds());
        row["alwaysOn"] = circuit.alwaysOn();
        result["circuits"].append(row);
    }
    const auto report = ElectricalControlValidationService().validate(graph);
    for (const auto& issue : report.issues()) result["diagnostics"].append(issue.message());
    PreviewLightCollection lights;
    lights.replaceGrammarLights(definition.lights());
    LightingStateEvaluator().apply(graph, &lights);
    for (const auto& light : lights.lights()) {
        const auto record = GpuLightRecordFactory().make(light, {}, {});
        Json::Value row;
        row["id"] = light.id().value();
        row["name"] = light.name();
        row["enabled"] = light.enabled();
        row["positionType"] = channels(record.position_and_type);
        row["directionRange"] = channels(record.direction_and_range);
        row["colorIntensity"] = channels(record.color_and_intensity);
        row["coneArea"] = channels(record.cone_and_area);
        row["twoSided"] = bool(record.metadata.x & 4u);
        result["lights"].append(row);
    }
    return result;
}
