# Android native grammar runtime

The included source snapshot is pinned to the commit in `desktop-commit.txt`. Its SHA-256 is stored in `snapshot.sha256`. The desktop parser, expansion, procedural mesh generation, spatial model, airflow, collision and rigid-body stepping, photometric light records, electrical graph evaluation and validation all run offline. The generic ServiceConnection and 4D patches preserve existing Android grammars. The current desktop snapshot includes the earlier airflow extension directly.

The Android scene adapter serializes world-space vertices, normals, source spans, object ownership, material descriptors and light state. The material resolver in `desktop_material.inc` comes from the pinned desktop editor source. To regenerate it, run `python3 tools/sync_material_parser.py /path/to/progen3d` from the project root. For WebAssembly, the build divides long generated table constructors into smaller functions to keep local variable counts within browser validation limits. It preserves the order and contents of the desktop tables.

### Build the APK

Use Android SDK Platform 35, Build Tools 35.0.0, JDK 21, Python 3 and zip. WebAssembly binaries and meshes are included.

```sh
export ANDROID_HOME=/path/to/android-sdk
bash build.sh
node tests/desktop_scene_test.cjs
node tests/airflow_test.cjs
```

The signed output is `app/build/ProGen3D_Android.apk`. The release APK uses the 0.41 Preview development signer. A fresh local build uses the key in PROGEN3D_KEY_DIR or the local development key created by build.sh. The source archive excludes signing credentials.

### Rebuild the engine

Use Emscripten 3.1.74, a C++17 host toolchain, patch, Python 3.10+ and GLM headers. The required C++ sources are included. Point GLM_INCLUDE at the directory containing the glm folder. Keep host and WebAssembly output in separate build directories.

```sh
export EMSDK=/path/to/emsdk
export GLM_INCLUDE=/path/to/include
python3 native_grammar/build.py
python3 native_grammar/build.py --host
NATIVE_PROBE="$PWD/native_grammar/build-host/native-scene" node tests/native_grammar_test.cjs
NATIVE_PROBE="$PWD/native_grammar/build-host/native-scene" node tests/desktop_scene_test.cjs
```

The worker accepts up to 2 MiB of source, 80,000 expanded actions, 5,000 instances and 600,000 triangles. Its WebAssembly heap grows on demand up to 512 MiB. Interactive requests time out after 30 seconds. Fixed-step replay has a 60-second limit and bounded instance-step and pair budgets. The desktop application mixes in a session seed, while the mobile worker uses the displayed seed directly.

### Refresh the desktop gallery

Start from a checkout of the pinned revision and the freshly built engine.

```sh
export PROGEN3D_CHECKOUT=/path/to/progen3d
python3 tests/native_corpus.py
python3 tools/sync_desktop_examples.py "$PROGEN3D_CHECKOUT"
node tools/desktop_motion_bounds.cjs
python3 pack_assets.py --preview-bootstrap
# Set CHROME_BIN to the absolute path of a WebGL-capable Chromium executable.
python3 tests/gallery_covers.py $(python3 -c 'import json; print(" ".join(c["id"] for c in json.load(open("web/gallery-catalog.json"))["entries"] if c["id"].startswith("desktop-") and not c.get("sourceOnly")))')
bash build.sh
python3 tests/desktop_scene_ui.py app/build/ProGen3D_Android.apk
```

The corpus report records a source hash, diagnostic or mesh count for each desktop grammar. The packaged UI test checks the desktop collection, rendered light-switch changes, deterministic body motion, PLY format, and reopening personal gallery settings.
