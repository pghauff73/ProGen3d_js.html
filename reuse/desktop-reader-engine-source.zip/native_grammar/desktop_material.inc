// Generated from src/imgui_main.cpp at 8923cafacff54cf20ad3d3d8ab8fa1e7339d5722
struct MaterialSwatch {
	float r = 1.0f;
	float g = 1.0f;
	float b = 1.0f;
};

struct ParsedMaterialSpec {
	std::string name;
	std::string family = "blend";
	std::string description;
	std::vector<std::string> color_names;
	std::vector<std::string> descriptors;
	std::vector<MaterialSwatch> palette;
	std::string wood_species;
	float opacity = 1.0f;
	float reflectance = 0.28f;
	float smoothness = 0.45f;
	float height_scale = 0.04f;
	float emission_strength = 0.0f;
	float uv_rotation_speed = 0.0f;
	float uv_activity = 0.0f;
	float pulse_strength = 0.0f;
	float normal_strength = 1.0f;
	float transmission = 0.0f;
	float index_of_refraction = 1.5f;
	float thickness = 0.01f;
	float anisotropic = 0.0f;
	float sheen = 0.0f;
	float clearcoat = 0.0f;
	float clearcoat_roughness = 0.0f;
	MaterialSwatch attenuation_color{1.0f, 1.0f, 1.0f};
	bool two_tone = false;
	bool vertical_pattern = false;
	bool emphasize_veins = false;
	uint32_t seed = 0;
};

enum class MaterialLexemeKind {
	Color,
	Family,
	Opacity,
	Finish
};

struct MaterialLexeme {
	std::string_view token;
	MaterialLexemeKind kind = MaterialLexemeKind::Color;
	MaterialSwatch swatch{};
};

struct MaterialTokenMatch {
	std::size_t position = 0;
	const MaterialLexeme *lexeme = nullptr;
};

float clamp01(float value)
{
	return std::clamp(value, 0.0f, 1.0f);
}

float lerp_scalar(float a, float b, float t)
{
	return a + (b - a) * t;
}

float smooth_curve(float value)
{
	value = clamp01(value);
	return value * value * (3.0f - 2.0f * value);
}

MaterialSwatch make_swatch(float r, float g, float b)
{
	return MaterialSwatch{r, g, b};
}

MaterialSwatch mix_swatch(const MaterialSwatch &a, const MaterialSwatch &b, float t)
{
	return make_swatch(lerp_scalar(a.r, b.r, t),
	                   lerp_scalar(a.g, b.g, t),
	                   lerp_scalar(a.b, b.b, t));
}

MaterialSwatch scale_swatch(const MaterialSwatch &color, float scale)
{
	return make_swatch(clamp01(color.r * scale),
	                   clamp01(color.g * scale),
	                   clamp01(color.b * scale));
}

MaterialSwatch lighten_swatch(const MaterialSwatch &color, float amount)
{
	return mix_swatch(color, make_swatch(1.0f, 1.0f, 1.0f), clamp01(amount));
}

MaterialSwatch darken_swatch(const MaterialSwatch &color, float amount)
{
	return mix_swatch(color, make_swatch(0.0f, 0.0f, 0.0f), clamp01(amount));
}

uint32_t stable_hash(const std::string &text)
{
	uint32_t hash = 2166136261u;
	for (unsigned char character : text) {
		hash ^= static_cast<uint32_t>(character);
		hash *= 16777619u;
	}
	return hash;
}

std::string join_strings(const std::vector<std::string> &parts)
{
	std::ostringstream stream;
	for (std::size_t index = 0; index < parts.size(); ++index) {
		if (index > 0) {
			stream << ", ";
		}
		stream << parts[index];
	}
	return stream.str();
}

void sort_and_unique_strings(std::vector<std::string> *values)
{
	if (values == nullptr) {
		return;
	}
	std::sort(values->begin(), values->end());
	values->erase(std::unique(values->begin(), values->end()), values->end());
}

template <std::size_t N>
std::vector<MaterialTokenMatch> scan_material_lexemes(const std::string &name,
                                                      const std::array<MaterialLexeme, N> &lexemes)
{
	std::vector<MaterialTokenMatch> matches;
	for (std::size_t position = 0; position < name.size();) {
		const MaterialLexeme *best_match = nullptr;
		for (const MaterialLexeme &lexeme : lexemes) {
			if (lexeme.token.empty() ||
			    position + lexeme.token.size() > name.size() ||
			    name.compare(position, lexeme.token.size(), lexeme.token) != 0) {
				continue;
			}
			if (best_match == nullptr || lexeme.token.size() > best_match->token.size()) {
				best_match = &lexeme;
			}
		}
		if (best_match != nullptr) {
			matches.push_back({position, best_match});
			position += best_match->token.size();
		} else {
			++position;
		}
	}
	return matches;
}

bool material_matches_token(const std::vector<MaterialTokenMatch> &matches, std::string_view token)
{
	for (const MaterialTokenMatch &match : matches) {
		if (match.lexeme != nullptr && match.lexeme->token == token) {
			return true;
		}
	}
	return false;
}

const std::array<MaterialLexeme, 78> &material_lexemes()
{
	static const std::array<MaterialLexeme, 78> lexemes = {{
		{"transparent", MaterialLexemeKind::Opacity, {}},
		{"translucent", MaterialLexemeKind::Opacity, {}},
		{"emissive", MaterialLexemeKind::Finish, {}},
		{"glowing", MaterialLexemeKind::Finish, {}},
		{"active", MaterialLexemeKind::Finish, {}},
		{"animated", MaterialLexemeKind::Finish, {}},
		{"rotating", MaterialLexemeKind::Finish, {}},
		{"reflective", MaterialLexemeKind::Finish, {}},
		{"weathered", MaterialLexemeKind::Finish, {}},
		{"polished", MaterialLexemeKind::Finish, {}},
		{"mirror", MaterialLexemeKind::Finish, {}},
		{"concrete", MaterialLexemeKind::Family, {}},
		{"ceramic", MaterialLexemeKind::Family, {}},
		{"plastic", MaterialLexemeKind::Family, {}},
		{"plaster", MaterialLexemeKind::Family, {}},
		{"grass", MaterialLexemeKind::Family, {}},
		{"brick", MaterialLexemeKind::Family, {}},
		{"neon", MaterialLexemeKind::Family, {}},
		{"floral", MaterialLexemeKind::Family, {}},
		{"boards", MaterialLexemeKind::Family, {}},
		{"orange", MaterialLexemeKind::Color, make_swatch(0.84f, 0.48f, 0.24f)},
		{"purple", MaterialLexemeKind::Color, make_swatch(0.58f, 0.42f, 0.76f)},
		{"silver", MaterialLexemeKind::Color, make_swatch(0.76f, 0.78f, 0.81f)},
		{"yellow", MaterialLexemeKind::Color, make_swatch(0.88f, 0.78f, 0.32f)},
		{"magenta", MaterialLexemeKind::Color, make_swatch(0.88f, 0.26f, 0.86f)},
		{"lime", MaterialLexemeKind::Color, make_swatch(0.62f, 0.94f, 0.24f)},
		{"violet", MaterialLexemeKind::Color, make_swatch(0.50f, 0.38f, 0.90f)},
		{"twotone", MaterialLexemeKind::Finish, {}},
		{"duotone", MaterialLexemeKind::Finish, {}},
		{"horizontal", MaterialLexemeKind::Finish, {}},
		{"vertical", MaterialLexemeKind::Finish, {}},
		{"veins", MaterialLexemeKind::Finish, {}},
		{"veined", MaterialLexemeKind::Finish, {}},
		{"oak", MaterialLexemeKind::Finish, {}},
		{"walnut", MaterialLexemeKind::Finish, {}},
		{"pine", MaterialLexemeKind::Finish, {}},
		{"cedar", MaterialLexemeKind::Finish, {}},
		{"birch", MaterialLexemeKind::Finish, {}},
		{"smooth", MaterialLexemeKind::Finish, {}},
		{"glossy", MaterialLexemeKind::Finish, {}},
		{"opaque", MaterialLexemeKind::Opacity, {}},
		{"shiny", MaterialLexemeKind::Finish, {}},
		{"rough", MaterialLexemeKind::Finish, {}},
		{"smoky", MaterialLexemeKind::Opacity, {}},
		{"white", MaterialLexemeKind::Color, make_swatch(0.94f, 0.95f, 0.96f)},
		{"green", MaterialLexemeKind::Color, make_swatch(0.35f, 0.62f, 0.39f)},
		{"black", MaterialLexemeKind::Color, make_swatch(0.16f, 0.18f, 0.20f)},
		{"chrome", MaterialLexemeKind::Color, make_swatch(0.84f, 0.87f, 0.90f)},
		{"copper", MaterialLexemeKind::Color, make_swatch(0.74f, 0.47f, 0.33f)},
		{"beige", MaterialLexemeKind::Color, make_swatch(0.81f, 0.75f, 0.63f)},
		{"glass", MaterialLexemeKind::Family, {}},
		{"marble", MaterialLexemeKind::Family, {}},
		{"stone", MaterialLexemeKind::Family, {}},
		{"metal", MaterialLexemeKind::Family, {}},
		{"paint", MaterialLexemeKind::Family, {}},
		{"brown", MaterialLexemeKind::Color, make_swatch(0.48f, 0.34f, 0.22f)},
		{"blue", MaterialLexemeKind::Color, make_swatch(0.28f, 0.50f, 0.84f)},
		{"grey", MaterialLexemeKind::Color, make_swatch(0.58f, 0.60f, 0.63f)},
		{"gray", MaterialLexemeKind::Color, make_swatch(0.58f, 0.60f, 0.63f)},
		{"gold", MaterialLexemeKind::Color, make_swatch(0.82f, 0.70f, 0.33f)},
		{"wood", MaterialLexemeKind::Family, {}},
		{"rock", MaterialLexemeKind::Family, {}},
		{"tile", MaterialLexemeKind::Family, {}},
		{"amber", MaterialLexemeKind::Color, make_swatch(0.92f, 0.66f, 0.22f)},
		{"teal", MaterialLexemeKind::Color, make_swatch(0.24f, 0.63f, 0.67f)},
		{"cyan", MaterialLexemeKind::Color, make_swatch(0.33f, 0.71f, 0.81f)},
		{"pink", MaterialLexemeKind::Color, make_swatch(0.87f, 0.63f, 0.73f)},
		{"red", MaterialLexemeKind::Color, make_swatch(0.78f, 0.28f, 0.24f)},
			{"aged", MaterialLexemeKind::Finish, {}},
			{"matte", MaterialLexemeKind::Finish, {}},
			{"satin", MaterialLexemeKind::Finish, {}},
			{"frosted", MaterialLexemeKind::Finish, {}},
			{"crystal", MaterialLexemeKind::Finish, {}},
			{"brushed", MaterialLexemeKind::Finish, {}},
			{"velvet", MaterialLexemeKind::Finish, {}},
			{"clearcoat", MaterialLexemeKind::Finish, {}},
			{"dull", MaterialLexemeKind::Finish, {}}
	}};
	return lexemes;
}

ParsedMaterialSpec parse_material_name(const std::string &material_name)
{
	ParsedMaterialSpec spec;
	spec.name = material_name.empty() ? "softwhitematteplaster" : material_name;
	spec.seed = stable_hash(spec.name);
	const auto &lexemes = material_lexemes();
	const std::vector<MaterialTokenMatch> matches = scan_material_lexemes(spec.name, lexemes);
	for (const MaterialTokenMatch &match : matches) {
		if (spec.color_names.size() >= 3) {
			break;
		}
		if (match.lexeme == nullptr || match.lexeme->kind != MaterialLexemeKind::Color) {
			continue;
		}
		const std::string color_name(match.lexeme->token);
		if (std::find(spec.color_names.begin(), spec.color_names.end(), color_name) == spec.color_names.end()) {
			spec.color_names.push_back(color_name);
			spec.palette.push_back(match.lexeme->swatch);
		}
	}
	const bool has_explicit_colors = !spec.palette.empty();
	const bool wants_boards = material_matches_token(matches, "boards");
	const bool wants_floral = material_matches_token(matches, "floral");
	const bool wants_horizontal = material_matches_token(matches, "horizontal");
	spec.vertical_pattern = material_matches_token(matches, "vertical");
	if (wants_horizontal) {
		spec.vertical_pattern = false;
	}
	spec.two_tone = material_matches_token(matches, "twotone") ||
	                material_matches_token(matches, "duotone");
	spec.emphasize_veins = material_matches_token(matches, "veins") ||
	                       material_matches_token(matches, "veined");

	auto set_palette = [&](const std::vector<std::string> &labels,
	                      const MaterialSwatch &first,
	                      const MaterialSwatch &second,
	                      const MaterialSwatch &third) {
		spec.color_names = labels;
		spec.palette = {first, second, third};
	};

	if (material_matches_token(matches, "oak")) {
		spec.wood_species = "oak";
	} else if (material_matches_token(matches, "walnut")) {
		spec.wood_species = "walnut";
	} else if (material_matches_token(matches, "pine")) {
		spec.wood_species = "pine";
	} else if (material_matches_token(matches, "cedar")) {
		spec.wood_species = "cedar";
	} else if (material_matches_token(matches, "birch")) {
		spec.wood_species = "birch";
	}

	if (!has_explicit_colors) {
		if (spec.wood_species == "oak") {
			set_palette({"oak", "natural"},
			            make_swatch(0.74f, 0.56f, 0.34f),
			            make_swatch(0.48f, 0.35f, 0.19f),
			            make_swatch(0.88f, 0.74f, 0.50f));
		} else if (spec.wood_species == "walnut") {
			set_palette({"walnut", "natural"},
			            make_swatch(0.42f, 0.28f, 0.18f),
			            make_swatch(0.24f, 0.16f, 0.10f),
			            make_swatch(0.58f, 0.40f, 0.24f));
		} else if (spec.wood_species == "pine") {
			set_palette({"pine", "natural"},
			            make_swatch(0.84f, 0.72f, 0.46f),
			            make_swatch(0.64f, 0.50f, 0.27f),
			            make_swatch(0.94f, 0.85f, 0.64f));
		} else if (spec.wood_species == "cedar") {
			set_palette({"cedar", "natural"},
			            make_swatch(0.72f, 0.40f, 0.24f),
			            make_swatch(0.46f, 0.23f, 0.14f),
			            make_swatch(0.84f, 0.58f, 0.38f));
		} else if (spec.wood_species == "birch") {
			set_palette({"birch", "natural"},
			            make_swatch(0.88f, 0.80f, 0.62f),
			            make_swatch(0.68f, 0.58f, 0.38f),
			            make_swatch(0.96f, 0.91f, 0.74f));
		} else if (wants_floral) {
			set_palette({"rose", "sage"},
			            make_swatch(0.86f, 0.60f, 0.70f),
			            make_swatch(0.92f, 0.89f, 0.82f),
			            make_swatch(0.48f, 0.66f, 0.46f));
		}
	}

	if (spec.palette.empty()) {
		spec.color_names = {"white", "grey"};
		spec.palette = {make_swatch(0.90f, 0.91f, 0.92f),
		                make_swatch(0.60f, 0.62f, 0.66f)};
	}
	if (spec.palette.size() == 1) {
		spec.palette.push_back(lighten_swatch(spec.palette.front(), 0.22f));
	}

	if (wants_floral) {
		spec.family = "floral";
		spec.reflectance = 0.20f;
		spec.smoothness = 0.40f;
		spec.height_scale = 0.050f;
	} else if (material_matches_token(matches, "metal")) {
		spec.family = "metal";
		spec.reflectance = 0.88f;
		spec.smoothness = 0.78f;
		spec.height_scale = 0.030f;
		} else if (material_matches_token(matches, "glass")) {
			spec.family = "glass";
			spec.opacity = 0.38f;
			spec.reflectance = 0.82f;
			spec.smoothness = 0.95f;
			spec.height_scale = 0.010f;
			spec.transmission = 0.94f;
			spec.index_of_refraction = 1.50f;
			spec.thickness = 0.018f;
			spec.clearcoat = 0.32f;
			spec.clearcoat_roughness = 0.05f;
	} else if (material_matches_token(matches, "neon")) {
		spec.family = "neon";
		spec.reflectance = 0.58f;
		spec.smoothness = 0.94f;
		spec.height_scale = 0.025f;
		spec.emission_strength = 1.15f;
	} else if (material_matches_token(matches, "grass")) {
		spec.family = "grass";
		spec.reflectance = 0.10f;
		spec.smoothness = 0.18f;
		spec.height_scale = 0.075f;
	} else if (material_matches_token(matches, "brick")) {
		spec.family = "brick";
		spec.reflectance = 0.12f;
		spec.smoothness = 0.26f;
		spec.height_scale = 0.085f;
	} else if (wants_boards) {
		spec.family = "boards";
		spec.reflectance = 0.22f;
		spec.smoothness = 0.40f;
		spec.height_scale = 0.060f;
	} else if (material_matches_token(matches, "wood") || !spec.wood_species.empty()) {
		spec.family = "wood";
		spec.reflectance = 0.20f;
		spec.smoothness = 0.38f;
		spec.height_scale = 0.055f;
	} else if (material_matches_token(matches, "marble")) {
		spec.family = "marble";
		spec.reflectance = 0.30f;
		spec.smoothness = 0.72f;
		spec.height_scale = 0.032f;
	} else if (material_matches_token(matches, "stone") || material_matches_token(matches, "rock")) {
		spec.family = "stone";
		spec.reflectance = 0.22f;
		spec.smoothness = 0.44f;
		spec.height_scale = 0.065f;
	} else if (material_matches_token(matches, "concrete")) {
		spec.family = "concrete";
		spec.reflectance = 0.16f;
		spec.smoothness = 0.32f;
		spec.height_scale = 0.070f;
	} else if (material_matches_token(matches, "ceramic") || material_matches_token(matches, "tile")) {
		spec.family = "ceramic";
		spec.reflectance = 0.46f;
		spec.smoothness = 0.84f;
		spec.height_scale = 0.040f;
	} else if (material_matches_token(matches, "plastic")) {
		spec.family = "plastic";
		spec.reflectance = 0.40f;
		spec.smoothness = 0.76f;
		spec.height_scale = 0.024f;
	} else if (material_matches_token(matches, "paint") || material_matches_token(matches, "plaster")) {
		spec.family = "paint";
		spec.reflectance = 0.26f;
		spec.smoothness = 0.58f;
		spec.height_scale = 0.028f;
	}

	if (material_matches_token(matches, "transparent")) {
		spec.opacity = 0.24f;
	}
	if (material_matches_token(matches, "translucent")) {
		spec.opacity = 0.45f;
	}
	if (material_matches_token(matches, "smoky")) {
		spec.opacity = std::min(spec.opacity, 0.68f);
		spec.attenuation_color = make_swatch(0.54f, 0.60f, 0.66f);
		spec.thickness = std::max(spec.thickness, 0.045f);
	}
	if (material_matches_token(matches, "opaque")) {
		spec.opacity = 1.0f;
	}

	if (material_matches_token(matches, "shiny") ||
	    material_matches_token(matches, "glossy") ||
	    material_matches_token(matches, "polished") ||
	    material_matches_token(matches, "reflective")) {
		spec.reflectance = std::max(spec.reflectance, 0.78f);
		spec.smoothness = std::max(spec.smoothness, 0.86f);
	}
	if (material_matches_token(matches, "mirror")) {
		spec.reflectance = std::max(spec.reflectance, 0.96f);
		spec.smoothness = std::max(spec.smoothness, 0.98f);
		spec.height_scale = std::min(spec.height_scale, 0.014f);
	}
	if (material_matches_token(matches, "frosted")) {
		spec.smoothness = std::min(spec.smoothness, 0.42f);
		spec.transmission = std::max(spec.transmission, 0.78f);
		spec.opacity = std::max(spec.opacity, 0.52f);
		spec.normal_strength = std::max(spec.normal_strength, 1.35f);
	}
	if (material_matches_token(matches, "crystal")) {
		spec.family = "glass";
		spec.smoothness = 0.99f;
		spec.reflectance = 0.90f;
		spec.transmission = 0.98f;
		spec.index_of_refraction = 1.52f;
		spec.opacity = 0.30f;
	}
	if (material_matches_token(matches, "brushed")) {
		spec.anisotropic = 0.72f;
		spec.smoothness = std::min(spec.smoothness, 0.66f);
	}
	if (material_matches_token(matches, "velvet")) {
		spec.sheen = 0.82f;
		spec.smoothness = std::min(spec.smoothness, 0.38f);
	}
	if (material_matches_token(matches, "clearcoat")) {
		spec.clearcoat = 1.0f;
		spec.clearcoat_roughness = 0.08f;
	}
	if (material_matches_token(matches, "smooth") || material_matches_token(matches, "satin")) {
		spec.smoothness = std::max(spec.smoothness, 0.78f);
	}
	if (material_matches_token(matches, "rough") ||
	    material_matches_token(matches, "aged") ||
	    material_matches_token(matches, "weathered")) {
		spec.smoothness = std::min(spec.smoothness, 0.28f);
	}
	if (material_matches_token(matches, "matte") || material_matches_token(matches, "dull")) {
		spec.reflectance = std::min(spec.reflectance, 0.22f);
		spec.smoothness = std::min(spec.smoothness, 0.42f);
	}
	if (material_matches_token(matches, "glowing") ||
	    material_matches_token(matches, "emissive")) {
		spec.emission_strength = std::max(spec.emission_strength, 0.95f);
		spec.smoothness = std::max(spec.smoothness, 0.72f);
	}
	if (material_matches_token(matches, "rotating")) {
		spec.uv_rotation_speed = std::max(spec.uv_rotation_speed, 0.70f);
		spec.pulse_strength = std::max(spec.pulse_strength, 0.12f);
	}
	if (material_matches_token(matches, "animated") ||
	    material_matches_token(matches, "active")) {
		spec.uv_activity = std::max(spec.uv_activity, 1.0f);
		spec.pulse_strength = std::max(spec.pulse_strength, 0.34f);
	}
	if (spec.family == "neon") {
		spec.emission_strength = std::max(spec.emission_strength,
		                                  material_matches_token(matches, "glowing") ? 1.85f : 1.25f);
	}
	if (spec.family == "glass") {
		spec.reflectance = std::max(spec.reflectance, 0.82f);
	}
	if (spec.family == "boards" && spec.wood_species.empty()) {
		spec.wood_species = "oak";
	}
	if (spec.two_tone) {
		spec.smoothness = std::max(spec.smoothness, 0.44f);
	}
	if (spec.emphasize_veins) {
		spec.height_scale = std::max(spec.height_scale, 0.050f);
	}
	if (!spec.wood_species.empty()) {
		spec.descriptors.push_back(spec.wood_species);
	}
	if (wants_horizontal || spec.vertical_pattern) {
		spec.descriptors.push_back(spec.vertical_pattern ? "vertical" : "horizontal");
	}
	if (spec.two_tone) {
		spec.descriptors.push_back("two tone");
	}
	if (spec.emphasize_veins) {
		spec.descriptors.push_back("veins");
	}
	if (spec.uv_rotation_speed > 0.0f) {
		spec.descriptors.push_back("rotating");
	}
	if (spec.uv_activity > 0.0f) {
		spec.descriptors.push_back("active");
	}
	sort_and_unique_strings(&spec.descriptors);

	spec.opacity = clamp01(spec.opacity);
	spec.reflectance = clamp01(spec.reflectance);
	spec.smoothness = clamp01(spec.smoothness);
	spec.height_scale = std::clamp(spec.height_scale, 0.0f, 0.16f);
	spec.emission_strength = std::clamp(spec.emission_strength, 0.0f, 2.5f);
	spec.pulse_strength = std::clamp(spec.pulse_strength, 0.0f, 1.0f);
	spec.normal_strength = std::clamp(spec.normal_strength, 0.0f, 2.0f);
	spec.transmission = clamp01(spec.transmission);
	spec.index_of_refraction = std::clamp(spec.index_of_refraction, 1.0f, 2.5f);
	spec.thickness = std::clamp(spec.thickness, 0.0f, 1.0f);
	spec.anisotropic = clamp01(spec.anisotropic);
	spec.sheen = clamp01(spec.sheen);
	spec.clearcoat = clamp01(spec.clearcoat);
	spec.clearcoat_roughness = clamp01(spec.clearcoat_roughness);

	std::ostringstream description;
	description << spec.family;
	if (!spec.descriptors.empty()) {
		description << " • " << join_strings(spec.descriptors);
	}
	description << " • " << join_strings(spec.color_names)
	            << " • opacity " << std::fixed << std::setprecision(2) << spec.opacity
	            << " • reflectance " << spec.reflectance
	            << " • smoothness " << spec.smoothness
		            << " • height " << spec.height_scale
		            << " • glow " << spec.emission_strength
		            << " • transmission " << spec.transmission
		            << " • ior " << spec.index_of_refraction;
	spec.description = description.str();
	return spec;
}
