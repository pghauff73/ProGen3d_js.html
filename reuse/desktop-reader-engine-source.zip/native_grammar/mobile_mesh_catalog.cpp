#include "geometry/service/GeneratedMeshProviderRegistry.h"
#include <cstdint>
#include <fstream>
#include <set>

// These payloads are built by the upstream resolver in upstream_port/build_vehicles.py.
class PackagedVehicleMeshProvider final : public GeneratedMeshProvider {
public:
    PackagedVehicleMeshProvider() {
        for (const char* variant : {"Reference","Track","Aero","Crossover"})
            for (const char* component : {"FixedBody","ClosuresClosed","ClosuresOpen","GlassClosed",
                     "GlassOpen","Suspension","NominalTyre","TyreSweep"})
                keys.insert(std::string("MCSMv22")+variant+component+"Mesh");
    }
    bool recognizes(const std::string& key) const override {return keys.count(key)>0;}
    GeneratedMeshResolutionResult resolve(const std::string& key, GeometryDetailLevel) const override {
        std::ifstream input("meshes/"+key+".mesh",std::ios::binary);
        uint32_t nv=0,nf=0;
        input.read(reinterpret_cast<char*>(&nv),4);input.read(reinterpret_cast<char*>(&nf),4);
        if(!input || nv==0 || nv>=65536 || nf==0 || nf>150000)
            return GeneratedMeshResolutionResult::createFailure("Packaged vehicle mesh unavailable: "+key);
        auto mesh=std::make_shared<Mesh>();
        mesh->vertices.reserve(nv);mesh->faces.reserve(nf);
        for(uint32_t i=0;i<nv;++i){
            float p[3]={};input.read(reinterpret_cast<char*>(p),12);
            mesh->vertices.emplace_back(p[0],p[1],p[2]);
        }
        for(uint32_t i=0;i<nf;++i){
            uint32_t f[3]={};input.read(reinterpret_cast<char*>(f),12);
            if(!input || f[0]>=nv || f[1]>=nv || f[2]>=nv)
                return GeneratedMeshResolutionResult::createFailure("Invalid packaged vehicle mesh: "+key);
            mesh->faces.emplace_back(f[0],f[1],f[2]);
        }
        mesh->calc_normals();
        return GeneratedMeshResolutionResult::createSuccess(GeneratedPrimitiveMesh(
            mesh,std::vector<MeshSurfaceTag>(nf,MeshSurfaceTag(MeshSurfaceRole::Outer))));
    }
private:
    std::set<std::string> keys;
};
void registerPackagedVehicleMeshes(){
    static const bool registered=[]{
        GeneratedMeshProviderRegistry::accessProcessRegistry().registerProvider(std::make_shared<PackagedVehicleMeshProvider>());
        return true;
    }();
    (void)registered;
}
