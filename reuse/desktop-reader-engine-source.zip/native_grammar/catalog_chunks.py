"""Keep generated table constructors within the WebAssembly per-function local limit."""
import re

def split_catalog(source):
    table = re.compile(
        r"(?P<type>std::vector<[^\n]+>) (?P<name>build_\w+)\(\)\n"
        r"\{\n\t(?P=type) records;\n(?P<reserve>\trecords.reserve\(\d+\);\n)"
        r"(?P<rows>(?:\trecords\.(?:push_back|emplace_back)\([^\n]+\);\n)+)"
        r"\treturn records;\n\}")
    def rewrite(match):
        rows = match['rows'].splitlines(keepends=True)
        batch_size = 20
        if len(rows) <= batch_size:
            return match[0]
        functions, calls = [], []
        for first in range(0, len(rows), batch_size):
            name = match['name'] + '_append_' + str(first)
            functions.append('static void ' + name + '(' + match['type'] + '& records)\n{\n' +
                             ''.join(rows[first:first+batch_size]) + '}\n')
            calls.append('\t' + name + '(records);\n')
        return ('\n'.join(functions) + '\n' + match['type'] + ' ' + match['name'] + '()\n{\n\t' +
                match['type'] + ' records;\n' + match['reserve'] + ''.join(calls) + '\treturn records;\n}')
    return table.sub(rewrite, source)
