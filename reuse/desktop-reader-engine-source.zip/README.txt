ProGen3D desktop grammar reader engine

Set GLM_INCLUDE to the directory containing glm/. Set EMXX to the Emscripten em++ driver or set EMSDK. Run python3 native_grammar/build.py. For a Linux comparison binary, use python3 native_grammar/build.py --host. The pinned C++ snapshot and the adapter sources are in native_grammar/.
